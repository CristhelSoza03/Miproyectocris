const ExcelJS = require ('exceljs');

exports.handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const { datos } = body;

        const workbook = new ExcelJS.Workbook();
        const worsheet = workbook.addWorksheet("Reporte");

        // Encabezados
        worksheet.addRow(["Nombre", "Categoría", "Precio"]);

        //Filas Dinamicas
        datos.forEach(item => {
            worsheet.addRow([
                item.nombre || "",
                item.categoria || "",
                item.precio || ""
            ]);
        });
        
        //Generar archivo en memoria
        const buffer = await workbook.xlsx.writeBuffer();

        return {
            statusCode: 200,
            headers: {
                "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "Content-Disposition": "attachment; filename=reporte.xlsx",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            isBase64Encoded: true,
            body: buffer.toString("base64")
        };
    } catch (error) {

        return{
            statusCode: 500,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({
                mensajes: "Error generando Excel",
                error: error.message
            })
        };
    }
};